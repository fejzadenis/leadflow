# LeadFlow Automation Pack (n8n)

Four ready-to-import n8n workflows for B2B lead generation — compliant by design (no LinkedIn scraping, no account bans) — plus a zero-setup demo that runs with no credentials.

## What's inside
| File | Purpose |
|---|---|
| workflows/00-quick-demo.json | Zero-setup demo: 6 messy rows → clean leads, patterns, drafts (no credentials, no network) |
| workflows/01-lead-import-csv.json | CSV (your export, as-is) → normalize headers → dedupe by email → Google Sheets |
| workflows/02-webhook-lead-capture.json | Webhook (any form) → Google Sheets |
| workflows/03-ai-email-drafter.json | Leads → AI-personalized email drafts (DeepSeek) → Google Sheets |
| workflows/04-email-patterns.json | Leads → generate candidate email patterns (FREE, no API) → Google Sheets |

## Requirements
- n8n (self-hosted Community = free, or n8n Cloud).
- Google account (Sheets) + a Google Sheets OAuth2 credential in n8n.
- DeepSeek API key — ONLY for workflow 03. In n8n: Credentials → New → Header Auth: Name = Authorization, Value = Bearer <your_key>.

## Setup
0. Prove it runs first: import `workflows/00-quick-demo.json` and Execute it — no credentials, nothing written. Then configure the rest.
1. n8n → Workflows → Import from File → choose each JSON.
2. In your Google Sheet create three tabs: `Sheet1` (your leads), `Drafts` (03 writes here), `Email Patterns` (04 writes here). Output tabs are separate on purpose — re-running a workflow can never treat generated rows as fresh leads.
3. Open each Google Sheets node → replace the placeholder spreadsheet (`YOUR_GOOGLE_SHEET_ID`) with your file, pick the tab listed above, then choose your Google Sheets credential.
4. Workflow 03 → select your DeepSeek (Header Auth) credential.
5. Save, then click **Execute workflow** (each workflow starts from a Manual Trigger; #02 starts from its Webhook).
6. Workflow 01's `Load CSV` node is preset to `/home/node/.n8n-files/sample-data/leads-sample.csv`, which the shipped Docker compose (`setup/`) mounts read-only - run it as imported. On npm or your own compose, n8n 2.x restricts file access to `~/.n8n-files` (`N8N_RESTRICT_FILE_ACCESS_TO`): copy the CSV there or widen the variable, then point the node at your path. On n8n Cloud, file reads are limited to `/home/node`, so run 01 self-hosted and start Cloud users on 02/03/04.

## Which CSV exports workflow 01 accepts
It renames the columns it recognises, so a Pipedrive / HubSpot / Mailchimp export runs without hand-editing the file:

- **address**: `email`, `Email`, `Email Address`, `Email - Work`, `Work Email`, `Business Email`, `Email 1`
- **name**: `First Name` + `Last Name` (or `First`/`Last`), or one `Name` / `Full Name` cell — `Petrović, Marko` is read first-name-first, `Acme, Inc.` is left alone
- **company**: `Company`, `Company Name`, `Organization`, `Account`
- **topic**: `Topic`, `Note`, `Notes`, `Reason` (workflow 03 uses it as the draft subject)

Every other column (`Phone`, `Owner`, …) is appended to your sheet untouched. If no address column can be found, 01 stops with `No email column found. Headers seen: …` instead of writing rows with an empty email; a column called `Email Status` is deliberately not treated as an address.

## Credentials needed
- Google Sheets: OAuth2.
- DeepSeek: Header Auth 'Authorization: Bearer <key>' (workflow 03 only).

## Limitations
- No LinkedIn scraping; leads come from your own CSV/forms.
- Dedupe in workflow 01 works **inside one import**: the same address twice in your CSV is one lead. It does not read rows already in the sheet, so importing the same file twice against the same tab appends it twice - import into a fresh tab if you re-run a file.
- Workflow 03 writes email DRAFTS to a sheet; it does NOT send email.
- Workflow 04 generates candidate email patterns (unverified) — verify before sending.
- 03 and 04 write to their own tabs (`Drafts`, `Email Patterns`) and skip rows that are already drafted/enriched, so re-runs are safe and idempotent.
- Workflow 04 normalizes accented letters in names (e.g. 'Kovač' → 'kovac') and drops duplicates, so generated patterns are always valid local parts.
- The target Google sheet must already exist; the sheet tab name is locale-dependent (e.g. 'Sheet1' or 'Лист1').

## Troubleshooting
- Setup errors (sheet not found, credential missing, 03 → 401, CSV path) are covered in TROUBLESHOOTING.md.

## Costs
- n8n self-hosted: $0. Google Sheets: $0.
- DeepSeek: ~$0.50 per 1M tokens (negligible at normal volume).

## Testing status (verified 2026-11-11)
- Google Sheets: create + append + read-back verified.
- Dedupe: 3 rows → 2 verified.
- Workflow 03: real AI draft generated and verified.
- Workflow 04: 10 email patterns generated from 2 leads verified.
- Workflow 01 header handling: Pipedrive (`Email - Work`, `Organization`), HubSpot (`Work Email`, `Company Name`), Mailchimp (`Email 1`) and a single `Petrović, Marko` cell all produce the same clean rows as the plain `email`/firstName file, and the same duplicate person collapses to one row (checked on every build by `test-wf01-headers.js`).
- All 4 workflow JSON files: valid, correct nodes, no secrets, no owner credentials/sheet IDs, each has a runnable trigger, and no node type that n8n has retired (checked on every build by `verify-pack.ps1`; workflow 01 uses `readWriteFile` + `extractFromFile`, the current replacements for the deprecated Read Binary Files / Spreadsheet File nodes).
