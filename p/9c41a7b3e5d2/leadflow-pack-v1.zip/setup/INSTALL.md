# INSTALL — running n8n for this pack

You need a working n8n instance. Any of these routes works; pick one.

## Route A — n8n Cloud (fastest, no server)
1. Create an account at n8n.cloud and open your instance.
2. Continue with **START-HERE.md** (`../START-HERE.md`).

## Route B — npm (local, no Docker)
1. `npm install -g n8n`
2. `n8n start`
3. Open http://127.0.0.1:5678 (local only).
Notes: default DB is SQLite in `~/.n8n`. Requires Node.js 20+.

## Route C — Docker Compose (recommended for isolation)
1. Install Docker Desktop (or Docker Engine on Linux/WSL2).
2. In this `setup/` folder: copy `.env.example` to `.env` and set `N8N_ENCRYPTION_KEY` to any long random string (keep it — it decrypts your stored credentials).
3. `docker compose up -d`
4. Open http://127.0.0.1:5678.
Optional in `.env`: `GENERIC_TIMEZONE` (default UTC).

The compose file already mounts this pack's `sample-data/` folder read-only at `/home/node/.n8n-files/sample-data` - inside the folder n8n 2.x allows file nodes to read by default (`N8N_RESTRICT_FILE_ACCESS_TO` defaults to `~/.n8n-files`). So workflow 01 reads its preset path without extra setup or env changes. Keep the compose file in `setup/` (the mount path is relative to it). For Route B (npm), copy `sample-data/leads-sample.csv` into `~/.n8n-files/` instead.

## Security (all routes)
- Bind to 127.0.0.1 only (never 0.0.0.0).
- Do not expose n8n to the internet without auth + TLS in front of it.
- Keep your DeepSeek key in an n8n credential, not in workflow JSON.

## After n8n is running
- Go to `../START-HERE.md` for the 15-minute pack setup.
- Errors during setup: `../TROUBLESHOOTING.md`.
