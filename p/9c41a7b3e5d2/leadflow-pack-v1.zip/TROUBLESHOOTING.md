# TROUBLESHOOTING — LeadFlow Automation Pack

Every item below was hit (and fixed) during our own end-to-end testing. Check here before emailing support.

## 1. "Could not find the sheet" / no rows appear
- The target Google Sheet must already exist. The pack does not create spreadsheets.
- Open each Google Sheets node -> Document: pick your file by name -> Sheet: pick the tab.
- Tab names are locale-dependent: `Sheet1` on English accounts, `Лист1`/`Hoja1` elsewhere. A mismatch fails silently with 0 rows written.

## 2. Credential errors on Google Sheets nodes
- Importing a workflow does **not** import credentials. Every Sheets node ships with the placeholder `YOUR_GOOGLE_SHEET_ID` and no credential selected.
- After import, open the node -> Credential -> "Create new" (OAuth2) or select an existing one -> sign in with the Google account that owns the sheet.
- The sheet must be shared with that same account (or "Anyone with the link: Editor" for testing only).

## 3. Workflow 03 returns HTTP 401 from api.deepseek.com
- 401 means the API key itself is invalid, not the node. Verify the key at platform.deepseek.com (Billing must show a positive balance; free-tier keys expire).
- Credential type must be **Header Auth**: Name = `Authorization`, Value = `Bearer sk-...` (the word "Bearer" plus one space, then the key). A missing "Bearer" prefix also yields 401.
- Workflows 01, 02 and 04 need no API key. If 03 is blocked, the pack still delivers value.

## 4. Workflow 01 can't read the CSV (ENOENT, or "Access to the file is not allowed")
Two different causes, same node - check which error you get.

**"Access to the file is not allowed." (n8n 2.x, the default)**
- n8n 2.x only lets file nodes read inside `~/.n8n-files` unless you change `N8N_RESTRICT_FILE_ACCESS_TO`. That is why our sample CSV is mounted at `/home/node/.n8n-files/sample-data/`, not at `/data/`.
- Docker route (shipped `setup/docker-compose.yml`): nothing to do - the folder is mounted there read-only and the node is preset to it.
- Your own compose file: add the same mount yourself (`- ./sample-data:/home/node/.n8n-files/sample-data:ro`).
- npm / bare-metal: copy the CSV into `~/.n8n-files/`, or set `N8N_RESTRICT_FILE_ACCESS_TO` to the folder holding it, then point the node at that absolute path.
- **n8n Cloud cannot read this file at all** (reads are limited to `/home/node`). Run workflow 01 on self-hosted n8n, or skip the CSV step on Cloud and start from 02/03/04 with your leads already in the sheet.

**"ENOENT: no such file or directory"**
- The path is read by the **n8n process**, not your laptop. It must exist inside the container (Docker) or on the host where n8n runs (npm).
- Windows hosts: use forward slashes (`C:/Users/you/leads.csv`).
- Header names are not the problem: 01 renames `Email - Work`, `Work Email`, `First Name`, `Company Name` and similar to the columns it uses (see §10). If it finds no address column it says so instead of writing blank rows.

## 5. Import fails / workflow looks empty
- Use a current n8n: the pack is built and tested on n8n 2.x (2.47.4). Old 1.x builds lack the `typeVersion` of some shipped nodes (Google Sheets 4.5, Read/Write Files 1.1, Extract from File 1.2).
- Import each JSON separately (Workflows -> Import from File); do not paste all four into one editor.

## 6. Workflow 02 webhook does nothing
- Webhooks only listen when the workflow is **Active** (toggle top-right). Manual "Execute workflow" waits for one test call only.
- Test URL is `/webhook-test/...`, production URL is `/webhook/...` - use the right one for the mode.

## 7. Workflow 04 emails bounce
- 04 **guesses** patterns (`first.last@`, `firstlast@`, `f.last@`, `flast@`, `first@`). They are unverified.
- Verify with your own SMTP check or a verification service before sending. Sending to guessed addresses hurts your domain reputation.

## 8. Re-running 03 or 04 fills my leads tab with junk rows
- Older builds appended output onto the same tab they read from, so a second run treated generated drafts/patterns as new leads.
- Current build writes to dedicated tabs (`Drafts`, `Email Patterns`) and skips rows that already carry a `draft` or `pattern` field. If you imported an older build, re-import 03/04 and re-point the append node at its own tab.
- Importing a fresh copy is safe: nothing is overwritten, only new rows are appended.

## 9. I imported the same CSV twice and my leads tab now has duplicates
- Workflow 01 dedupes **inside one import**: the same address appearing twice in the CSV (different topic, upper case, stray spaces) becomes one row, and a row without an email is kept unless name + company repeat exactly.
- It does **not** read the rows already in your sheet, so running the same file twice against the same tab appends it twice. If you re-run a file, import into a fresh tab, or delete the previously imported rows first.
- Rows are passed through as they are in your CSV - the dedupe compares addresses trimmed and lowercased, it does not rewrite the cell value.

## 10. My export says "Email - Work" / "Work Email" — does workflow 01 understand it?
Yes, no editing needed. 01 renames the columns it recognises to the ones the rest of the workflow uses:
- **address**: `email`, `Email Address`, `Email - Work`, `Work Email`, `Business Email`, `Email 1`, `E-mail`
- **name**: `First Name` + `Last Name`, or one `Name` / `Full Name` cell (`Petrović, Marko` is reordered; `Acme, Inc.` is left as it is)
- **company**: `Company`, `Company Name`, `Organization`, `Account`
- **topic**: `Topic`, `Note`, `Notes`, `Reason`
Everything else (`Phone`, `Owner`, custom fields) is appended to the sheet as-is, so nothing is lost.
If the run stops with `No email column found. Headers seen: …`, the list it prints is your file's real header row: rename the address column to `email` (or one of the names above) and run again. A column named `Email Status` / `Email Valid` is deliberately not used as an address.

## 11. Names arrive as ???? or "Ã©" instead of Đorđe / François

The characters were destroyed before workflow 01 saw them, or they were written by Excel in an encoding nobody asked for. The two shapes have different answers.

**Shape A — the cell holds `????` or `?or?e`.**
Excel on a Serbian, Polish, Czech or Hungarian Windows writes CSV in **Windows-1250** by default. n8n's **Extract from File** node decodes every CSV as UTF-8, so each byte above 0x7F that is not valid UTF-8 becomes a replacement character and the name is gone at that point - not lost later in the sheet.

Workflow 01 therefore carries a **Decode CSV bytes** node ahead of the parser. It reads the raw bytes and picks the first encoding that is provably correct, in this order:
1. **BOM** - a UTF-8 or UTF-16 byte-order mark settles it, and the BOM itself is stripped.
2. **Strict UTF-8** - the file decodes cleanly, so it is UTF-8; nothing is rewritten.
3. **Windows-1250** - strict UTF-8 failed, so the bytes are read with the 1250 table (the one Excel used for those locales).

The node rewrites the file as UTF-8 and records the choice in `encoding_used`, so the CSV parser downstream only ever sees valid UTF-8. Check that field on the node's output if you want to know which route your file took. It does not guess between 1250 and 1252 by "most accented letters": a wrong guess silently renames people.

**If the cell already shows `?` after the Decode node**, the bytes were replaced before the file reached n8n - by a previous save in a text editor, by a mail gateway, or by an export that was already damaged. No decoder can restore a byte that was replaced; the honest fix is to re-export from the source system. This is the one failure the pack does not fix, and it is stated in README's Limitations on purpose.

**Shape B — the cell holds `FranÃ§ois` or `KovÃ¡Ä`.**
That is valid UTF-8 that some earlier tool decoded with a single-byte encoding and saved again. Because the text *is* valid UTF-8, the Decode node correctly leaves it alone. The free browser tool at the LeadFlow site reverses this shape cell by cell (it rebuilds the bytes and checks that the result is strict UTF-8), a file at a time; the pack's workflow 01 does not, so repair those rows before import or hand the file over as described on the site.

**UTF-16 exports.** Excel's "Unicode Text (*.txt)" and some CRM exports are UTF-16. **Extract from File** decodes UTF-8 only, so those arrive full of null bytes and the header is unrecognised. Save as **CSV UTF-8** instead, or convert once with your spreadsheet's "Save As -> CSV UTF-8 (Comma delimited)".

## Still stuck?
Reply to your purchase email with: n8n version, the failing workflow number, and the exact error text. Refund window and terms are in LICENSE.txt.
