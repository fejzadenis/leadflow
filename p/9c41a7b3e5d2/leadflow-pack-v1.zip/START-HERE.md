# START HERE — LeadFlow Automation Pack

## What it is
4 importable n8n workflows for compliant B2B lead generation (no LinkedIn scraping, no account bans), plus a zero-setup demo that proves your n8n runs the pack before you connect anything.

## 60-second proof (no setup at all)
1. Import `workflows/00-quick-demo.json`.
2. Click **Execute workflow** on the node named `Start - click Execute workflow`.
3. Open the last node, `Summary - what just happened`: 6 messy sample rows -> 3 clean leads, 15 email patterns, 3 drafted emails, **0 emails sent**, **0 network calls**, **no credentials used**.

It runs entirely in Code nodes: it reads no file, writes nothing, calls nothing. If this works, your n8n can run the pack. The other four workflows add Google Sheets as storage.

## 15-minute setup
1. Have n8n ready — self-hosted Community is free (install guide: `setup/INSTALL.md`) or use n8n Cloud.
2. In n8n: **Workflows → Import from File** → import the four workflow files (`01`–`04`) in `workflows/`.
3. Create a Google Sheet with these headers on a tab named `Sheet1`: `firstName, lastName, company, domain, email, topic`. (Your CSV does not have to use those names — workflow 01 renames `Email - Work`, `Work Email`, `First Name`, `Company Name` and similar on the way in.) Add two more empty tabs: `Drafts` (workflow 03 output) and `Email Patterns` (workflow 04 output).
4. Add a Google Sheets **OAuth2** credential in n8n; in each Google Sheets node select your spreadsheet + the tab named above.
5. (Workflow 03 only) Add a **Header Auth** credential: Name = `Authorization`, Value = `Bearer <your DeepSeek key>`.
6. Open a workflow → click **Execute workflow** (01/03/04 start from a Manual Trigger, 02 from its Webhook).

## Try it with the sample data
- Workflow 01 ('Load CSV' node): the path is preset to `/home/node/.n8n-files/sample-data/leads-sample.csv`, and the shipped Docker compose (`setup/docker-compose.yml`) mounts the pack's `sample-data/` exactly there, read-only — so the **Docker route runs it as-is**: set your sheet, Execute, expect deduped rows appended.
  - npm / your own n8n: n8n 2.x only lets the file nodes read inside `~/.n8n-files` (env `N8N_RESTRICT_FILE_ACCESS_TO`). Copy `sample-data/leads-sample.csv` into `~/.n8n-files/` and point the node at that absolute path, or widen the env var to the folder you keep it in.
  - n8n Cloud: file reads are limited to `/home/node`, so run 01 self-hosted (Docker/npm) - on Cloud, start from 02/03/04 with your leads already in the sheet.

## Requirements
- n8n, a Google account, and (only for workflow 03) a DeepSeek API key.

## Limitations
- No scraping; leads come from your own CSV/forms.
- Workflow 03 writes DRAFTS to a sheet (it does not send email).
- Workflow 04 generates candidate email patterns (unverified — verify before sending).

## Docs
- `README.md` (overview) · `DEMO.md` (2-min walkthrough) · `setup/INSTALL.md` (n8n install) · `TROUBLESHOOTING.md` (sheet, credentials, 401, CSV path, webhook, patterns).

## Support & license
- Questions, a broken download, or a refund (14 days): write to perun.intelligence@gmail.com — that address is read every day and a person answers.
- Terms, refunds (14 days), and usage rights: see `LICENSE.txt`.
