# DEMO.md — 2-minute walkthrough of LeadFlow

## Prereqs
- n8n running (localhost:5678).
- Google Sheets OAuth credential connected in n8n.
- DeepSeek Header Auth credential (workflow 03 only).

## Script
0. **00 Zero-setup demo:** import 00-quick-demo.json, Execute → summary shows 6 messy rows → 3 clean leads, 15 patterns, 3 drafts, 0 sent, no credentials. Do this before connecting anything (no prereqs needed).
1. **01 CSV import:** import 01-*.json, set Load CSV path to the sample, select your sheet, Execute → leads appear (deduped).
2. **02 Webhook:** activate 02-*.json, POST {firstName,lastName,company,email} to the webhook URL → row appended.
3. **03 AI email:** Execute on leads → personalized drafts written to a sheet. (Verified output: 'Hi Jane — I came across Acme Studio ...')
4. **04 Patterns:** Execute → candidate emails (jane.doe@, janedoe@, j.doe@, jdoe@, jane@).

## Verified expected outputs (2026-11-11)
- 00: 6 messy rows → 3 clean (1 duplicate, 1 missing domain, 1 missing email rejected with reasons), 15 patterns, 3 drafts, 0 network calls (2026-11-12).
- 01: 6 input rows → 5 unique appended (dedupe confirmed).
- 03: real DeepSeek draft, values interpolated correctly.
- 04: 5 patterns per lead (10 from 2 leads).
